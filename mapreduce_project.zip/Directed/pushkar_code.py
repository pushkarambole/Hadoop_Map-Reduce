import os
import sys 
import datetime
from operator import itemgetter
input_path = '/home/amboleps/ccproject2/directed/inputs/part-r-00000'
input_file=open('/home/amboleps/ccproject2/directed/inputs/part-r-00000')

first={}
second={}

for each_line in input_file:
    total_w=each_line.split()
    if len(total_w)!=0:
        string1=str(total_w[1])
        string2=total_w[0]
        list=string1.split('#')
        string1=list[1]
        first.update({string2:int(string1)})
        second.update({list[2]:list[0]})


sorted_list=sorted(first.items(), key=itemgetter(1))

ts = str(datetime.datetime.utcnow() - datetime.timedelta(hours=5))

output_path = '/home/amboleps/ccproject2/directed/outputs/output_file.txt'
output_file = open(output_path,'a')

output_file.write('\nNode' + ' ' + str(sorted_list[0][0]) + ' ' + 'having Minimum Connectivity of' + ' '+ str(sorted_list[0][1]))
output_file.write('\nNode' + ' ' + str(sorted_list[-1][0]) + ' ' + 'having Maximum Connectivity of' + ' '+ str(sorted_list[-1][1]))

for x,y in second.items():
    if x == sorted_list[-1][0]:
                output_file.write('\nNode'+' '+str(x)+ ' '+'having longest adj list of' + ' ' + str(y))

output_file.write("\nExecuted on: " + ts)
output_file.write("\n*********************************************************\n\n\n\n")